import { useEffect, useRef, useState, type KeyboardEvent } from "react";
import { Mic, Paperclip, Send, Square, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Tooltip } from "@/components/ui/tooltip";
import { t } from "@/lib/aegis/i18n";
import { useAegisStore } from "@/lib/aegis/store";
import { useChat } from "@/lib/aegis/use-chat";
import type { Attachment } from "@/lib/aegis/types";
import { LIMITS } from "@/lib/aegis/types";
import { uid } from "@/lib/utils";
import { canListen, startListening } from "@/lib/aegis/voice";

export function Composer() {
  const language = useAegisStore((s) => s.language);
  const isProcessing = useAegisStore((s) => s.isProcessing);
  const { send } = useChat();
  const ui = t(language);
  const [value, setValue] = useState("");
  const [listening, setListening] = useState(false);
  const [files, setFiles] = useState<Attachment[]>([]);
  const areaRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const stopRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    const el = areaRef.current;
    if (!el) return;
    el.style.height = "0px";
    el.style.height = `${Math.min(el.scrollHeight, 140)}px`;
  }, [value]);

  useEffect(() => {
    return () => {
      stopRef.current?.();
    };
  }, []);

  function onKey(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void submit();
    }
  }

  async function submit() {
    if (isProcessing) return;
    const text = value;
    const attachments = files;
    setValue("");
    setFiles([]);
    await send(text, attachments);
    areaRef.current?.focus();
  }

  function toggleMic() {
    if (listening) {
      stopRef.current?.();
      stopRef.current = null;
      setListening(false);
      return;
    }
    if (!canListen()) {
      toast.error(ui.errorSpeech);
      return;
    }
    setListening(true);
    stopRef.current = startListening(
      language,
      (transcript) => {
        setValue((cur) => (cur ? `${cur.trim()} ${transcript}` : transcript));
      },
      () => {
        setListening(false);
        stopRef.current = null;
      },
      (message) => toast.error(message),
    );
  }

  async function onFiles(list: FileList | null) {
    if (!list?.length) return;
    const next: Attachment[] = [];
    for (const file of Array.from(list).slice(0, 3)) {
      if (!file.type.startsWith("image/")) continue;
      if (file.size > LIMITS.attachmentBytes) continue;
      const dataUrl = await readFile(file);
      next.push({ id: uid("a"), name: file.name, mime: file.type, dataUrl });
    }
    setFiles((cur) => [...cur, ...next].slice(0, 3));
    if (fileRef.current) fileRef.current.value = "";
  }

  const remaining = LIMITS.message - value.length;

  return (
    <form
      className="border-t border-line bg-canvas/80 p-3 backdrop-blur-sm sm:p-4"
      onSubmit={(e) => {
        e.preventDefault();
        void submit();
      }}
    >
      <div className="mx-auto max-w-3xl">
        {files.length ? (
          <div className="mb-2 flex gap-2">
            {files.map((f) => (
              <div key={f.id} className="relative">
                <img src={f.dataUrl} alt={f.name} className="h-14 w-14 rounded-md object-cover" />
                <button
                  type="button"
                  className="absolute -right-1.5 -top-1.5 flex size-6 items-center justify-center rounded-full bg-elevated text-ink"
                  aria-label={ui.close}
                  onClick={() => setFiles((cur) => cur.filter((x) => x.id !== f.id))}
                >
                  <X className="size-3" />
                </button>
              </div>
            ))}
          </div>
        ) : null}
        <div className="flex items-end gap-2 rounded-2xl border border-line bg-surface p-2 shadow-border">
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="sr-only"
            onChange={(e) => void onFiles(e.target.files)}
          />
          <Tooltip content={ui.composerAttach}>
            <button
              type="button"
              className="msg-action mb-0.5"
              aria-label={ui.composerAttach}
              onClick={() => fileRef.current?.click()}
            >
              <Paperclip className="size-4" />
            </button>
          </Tooltip>
          <textarea
            ref={areaRef}
            rows={1}
            value={value}
            onChange={(e) => setValue(e.target.value.slice(0, LIMITS.message))}
            onKeyDown={onKey}
            placeholder={listening ? ui.listening : ui.composerPlaceholder}
            aria-label={ui.composerPlaceholder}
            className="max-h-36 min-h-11 flex-1 resize-none bg-transparent py-2.5 text-sm text-ink outline-none placeholder:text-subtle"
          />
          <Tooltip content={listening ? ui.composerMicOff : ui.composerMic}>
            <button
              type="button"
              className={`msg-action mb-0.5 ${listening ? "text-danger" : ""}`}
              aria-label={listening ? ui.composerMicOff : ui.composerMic}
              aria-pressed={listening}
              onClick={toggleMic}
            >
              {listening ? <Square className="size-3.5" /> : <Mic className="size-4" />}
            </button>
          </Tooltip>
          <Button
            type="submit"
            size="icon"
            className="shrink-0"
            disabled={isProcessing || (!value.trim() && files.length === 0)}
            aria-label={ui.composerSend}
          >
            <Send className="size-4" />
          </Button>
        </div>
        <p className="mt-2 text-right text-[11px] tabular-nums text-subtle">{remaining}</p>
      </div>
    </form>
  );
}

function readFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}
