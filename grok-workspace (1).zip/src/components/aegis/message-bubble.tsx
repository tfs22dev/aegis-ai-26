import { useState } from "react";
import { Copy, RefreshCw, ThumbsDown, ThumbsUp, Volume2 } from "lucide-react";
import { toast } from "sonner";
import { Markdown } from "@/lib/aegis/markdown";
import { t } from "@/lib/aegis/i18n";
import { useAegisStore } from "@/lib/aegis/store";
import type { ChatMessage, ToolName } from "@/lib/aegis/types";
import { formatClock } from "@/lib/utils";
import { speak, stopSpeaking } from "@/lib/aegis/voice";
import { AegisMark } from "./mark";
import { Tooltip } from "@/components/ui/tooltip";

const TOOL_LABEL: Record<ToolName, { pt: string; en: string }> = {
  calculator: { pt: "Calculadora", en: "Calculator" },
  wikipedia: { pt: "Wikipedia", en: "Wikipedia" },
  search: { pt: "Pesquisa", en: "Search" },
  images: { pt: "Imagens", en: "Images" },
  time: { pt: "Hora local", en: "Local time" },
  model: { pt: "Modelo", en: "Model" },
  hybrid: { pt: "Modelo + fontes", en: "Model + sources" },
  local: { pt: "Local", en: "Local" },
};

export function MessageBubble({
  message,
  onRegenerate,
}: {
  message: ChatMessage;
  onRegenerate?: () => void;
}) {
  const language = useAegisStore((s) => s.language);
  const voiceEnabled = useAegisStore((s) => s.voiceEnabled);
  const feedback = useAegisStore((s) => s.feedback[message.id]);
  const setFeedback = useAegisStore((s) => s.setFeedback);
  const userName = useAegisStore((s) => s.userName);
  const ui = t(language);
  const isUser = message.role === "user";
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      toast.success(ui.copied);
      window.setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error(ui.errorGeneric);
    }
  }

  function listen() {
    stopSpeaking();
    const result = speak(message.content, language);
    if (!result.ok) toast.error(result.message);
  }

  return (
    <article
      className={`flex gap-3 ${isUser ? "flex-row-reverse" : "flex-row"}`}
      aria-label={isUser ? ui.you : ui.aegis}
    >
      <div
        className={`mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-full ${
          isUser ? "bg-elevated text-xs font-medium text-ink" : "border border-line text-ink"
        }`}
        aria-hidden="true"
      >
        {isUser ? (
          (userName || "U").slice(0, 1).toUpperCase()
        ) : (
          <AegisMark className="size-4" title="" />
        )}
      </div>
      <div className={`min-w-0 max-w-[min(100%,42rem)] flex-1 ${isUser ? "text-right" : ""}`}>
        <div className="mb-1 flex items-center gap-2 text-[11px] text-subtle">
          <span className={`font-medium ${isUser ? "ml-auto" : ""}`}>{isUser ? ui.you : ui.aegis}</span>
          <time dateTime={new Date(message.createdAt).toISOString()}>
            {formatClock(message.createdAt, language)}
          </time>
        </div>
        <div
          className={
            isUser
              ? "inline-block rounded-2xl rounded-tr-md bg-elevated px-4 py-2.5 text-left text-sm leading-relaxed text-ink"
              : "text-sm leading-relaxed text-ink"
          }
        >
          {message.attachments?.length ? (
            <div className="mb-2 flex flex-wrap gap-2">
              {message.attachments.map((a) => (
                <img
                  key={a.id}
                  src={a.dataUrl}
                  alt={a.name}
                  className="h-20 w-20 rounded-lg object-cover outline outline-1 -outline-offset-1 outline-white/10"
                />
              ))}
            </div>
          ) : null}
          {isUser ? <p className="whitespace-pre-wrap text-pretty">{message.content}</p> : <Markdown text={message.content} />}
        </div>

        {!isUser ? (
          <div className="mt-3 flex flex-wrap items-center gap-1">
            {message.tool ? (
              <span className="mr-2 text-[11px] uppercase tracking-wider text-subtle">
                {ui.usedTool}: {TOOL_LABEL[message.tool][language]}
              </span>
            ) : null}
            {voiceEnabled ? (
              <Tooltip content={ui.listen}>
                <button type="button" className="msg-action" aria-label={ui.listen} onClick={listen}>
                  <Volume2 className="size-3.5" />
                </button>
              </Tooltip>
            ) : null}
            <Tooltip content={copied ? ui.copied : ui.copy}>
              <button type="button" className="msg-action" aria-label={ui.copy} onClick={copy}>
                <Copy className="size-3.5" />
              </button>
            </Tooltip>
            {onRegenerate ? (
              <Tooltip content={ui.regenerate}>
                <button type="button" className="msg-action" aria-label={ui.regenerate} onClick={onRegenerate}>
                  <RefreshCw className="size-3.5" />
                </button>
              </Tooltip>
            ) : null}
            <Tooltip content={ui.feedbackUp}>
              <button
                type="button"
                className={`msg-action ${feedback === "up" ? "text-ink" : ""}`}
                aria-label={ui.feedbackUp}
                aria-pressed={feedback === "up"}
                onClick={() => setFeedback(message.id, "up")}
              >
                <ThumbsUp className="size-3.5" />
              </button>
            </Tooltip>
            <Tooltip content={ui.feedbackDown}>
              <button
                type="button"
                className={`msg-action ${feedback === "down" ? "text-ink" : ""}`}
                aria-label={ui.feedbackDown}
                aria-pressed={feedback === "down"}
                onClick={() => setFeedback(message.id, "down")}
              >
                <ThumbsDown className="size-3.5" />
              </button>
            </Tooltip>
          </div>
        ) : null}

        {!isUser && message.sources?.length ? (
          <ul className="mt-3 space-y-1 border-t border-line pt-3 text-xs text-muted">
            <li className="text-[11px] font-medium uppercase tracking-wider text-subtle">{ui.sourceLabel}</li>
            {message.sources.map((s) => (
              <li key={s.url}>
                <a href={s.url} target="_blank" rel="noopener noreferrer" className="md-link">
                  {s.title}
                </a>
              </li>
            ))}
          </ul>
        ) : null}

        {!isUser && message.images?.length ? (
          <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
            {message.images.map((img) => (
              <a
                key={img.url}
                href={img.pageUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group overflow-hidden rounded-lg bg-elevated"
              >
                <img
                  src={img.thumb}
                  alt={img.title}
                  loading="lazy"
                  className="aspect-[4/3] w-full object-cover outline outline-1 -outline-offset-1 outline-white/10"
                />
                <p className="truncate px-2 py-1.5 text-[11px] text-muted">{img.title}</p>
              </a>
            ))}
          </div>
        ) : null}
      </div>
    </article>
  );
}
