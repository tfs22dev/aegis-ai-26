import { useEffect } from "react";
import { Menu, Settings, Volume2, VolumeX } from "lucide-react";
import { t } from "@/lib/aegis/i18n";
import { getAiStatus } from "@/lib/aegis/server";
import { useAegisStore } from "@/lib/aegis/store";
import { stopSpeaking } from "@/lib/aegis/voice";
import { Tooltip } from "@/components/ui/tooltip";
import { ChatView } from "./chat-view";
import { PanelHost } from "./panels";
import { Sidebar } from "./sidebar";
import { AegisMark } from "./mark";

export function AppShell() {
  const language = useAegisStore((s) => s.language);
  const sidebarOpen = useAegisStore((s) => s.sidebarOpen);
  const setSidebarOpen = useAegisStore((s) => s.setSidebarOpen);
  const setPanel = useAegisStore((s) => s.setPanel);
  const setModelAvailable = useAegisStore((s) => s.setModelAvailable);
  const modelAvailable = useAegisStore((s) => s.modelAvailable);
  const voiceEnabled = useAegisStore((s) => s.voiceEnabled);
  const setVoiceEnabled = useAegisStore((s) => s.setVoiceEnabled);
  const ui = t(language);

  useEffect(() => {
    let alive = true;
    getAiStatus()
      .then((s) => {
        if (alive) setModelAvailable(s.available);
      })
      .catch((err) => {
        console.error("ai status", err);
        if (alive) setModelAvailable(false);
      });
    return () => {
      alive = false;
    };
  }, [setModelAvailable]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") {
        setPanel(null);
        setSidebarOpen(false);
        stopSpeaking();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setPanel, setSidebarOpen]);

  return (
    <div className="flex h-dvh overflow-hidden bg-canvas text-ink">
      <aside className="hidden w-60 shrink-0 border-r border-line lg:block">
        <Sidebar />
      </aside>

      {sidebarOpen ? (
        <div className="fixed inset-0 z-40 lg:hidden">
          <button
            type="button"
            className="absolute inset-0 bg-canvas/50"
            aria-label={ui.close}
            onClick={() => setSidebarOpen(false)}
          />
          <div className="panel-left relative h-full w-[min(100%,18rem)] border-r border-line">
            <Sidebar mobile />
          </div>
        </div>
      ) : null}

      <div className="relative flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center gap-3 border-b border-line px-3 sm:px-4">
          <button
            type="button"
            className="msg-action lg:hidden"
            aria-label={ui.openMenu}
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="size-4" />
          </button>
          <AegisMark className="hidden size-5 sm:block lg:hidden" />
          <p className="min-w-0 flex-1 truncate font-display text-lg tracking-tight">{ui.appName}</p>
          <div className="flex items-center gap-2 text-xs text-muted">
            <span className="inline-flex items-center gap-1.5">
              <span className="size-1.5 rounded-full bg-ok" aria-hidden="true" />
              <span className="hidden sm:inline">{ui.online}</span>
            </span>
            <span className="hidden text-subtle sm:inline">·</span>
            <span className="hidden sm:inline">{modelAvailable ? ui.modelConnected : ui.modelLocal}</span>
          </div>
          <Tooltip content={ui.composerVoice}>
            <button
              type="button"
              className="msg-action"
              aria-label={ui.composerVoice}
              aria-pressed={voiceEnabled}
              onClick={() => {
                if (voiceEnabled) stopSpeaking();
                setVoiceEnabled(!voiceEnabled);
              }}
            >
              {voiceEnabled ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
            </button>
          </Tooltip>
          <Tooltip content={ui.settings}>
            <button
              type="button"
              className="msg-action"
              aria-label={ui.settings}
              onClick={() => setPanel("settings")}
            >
              <Settings className="size-4" />
            </button>
          </Tooltip>
        </header>
        <ChatView />
        <PanelHost />
      </div>
    </div>
  );
}
