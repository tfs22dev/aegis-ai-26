import { useEffect, useState, type FormEvent } from "react";
import { RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { captchaMatches, randomCaptcha } from "@/lib/aegis/captcha";
import { t } from "@/lib/aegis/i18n";
import { useAegisStore } from "@/lib/aegis/store";
import { AegisMark } from "./mark";

export function GateScreen() {
  const language = useAegisStore((s) => s.language);
  const setLanguage = useAegisStore((s) => s.setLanguage);
  const verify = useAegisStore((s) => s.verify);
  const savedName = useAegisStore((s) => s.userName);
  const ui = t(language);

  const [name, setName] = useState(savedName);
  const [code, setCode] = useState("");
  const [challenge, setChallenge] = useState("AEGIS");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setChallenge(randomCaptcha());
  }, []);

  function refreshCaptcha() {
    setChallenge(randomCaptcha());
    setCode("");
    setError(null);
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const trimmed = name.trim();
    if (trimmed.length < 2) {
      setError(ui.gateErrorName);
      return;
    }
    if (!captchaMatches(challenge, code)) {
      setError(ui.gateErrorCaptcha);
      setChallenge(randomCaptcha());
      setCode("");
      return;
    }
    verify(trimmed);
  }

  return (
    <main className="relative flex min-h-dvh items-center justify-center overflow-hidden bg-canvas px-4 py-10 text-ink">
      <div className="gate-grid pointer-events-none absolute inset-0" aria-hidden="true" />
      <div className="relative w-full max-w-md">
        <div className="stagger-in mb-10 flex flex-col items-center text-center">
          <AegisMark className="mb-5 size-12" />
          <p className="font-display text-3xl tracking-tight text-ink">{ui.brand}</p>
          <p className="mt-2 text-xs font-medium uppercase tracking-[0.22em] text-muted">
            {ui.gateKicker}
          </p>
        </div>

        <form
          onSubmit={onSubmit}
          className="stagger-in stagger-2 rounded-2xl border border-line bg-surface p-5 shadow-border sm:p-6"
        >
          <p className="mb-6 text-sm leading-relaxed text-muted text-pretty">{ui.gateLead}</p>

          <div className="mb-4 flex gap-2" role="group" aria-label={ui.gateLang}>
            <button
              type="button"
              className={`h-9 flex-1 rounded-md text-sm font-medium transition-[background-color,color] duration-150 ${
                language === "pt" ? "bg-elevated text-ink" : "text-muted hover:text-ink"
              }`}
              onClick={() => setLanguage("pt")}
              aria-pressed={language === "pt"}
            >
              PT · {ui.portuguese}
            </button>
            <button
              type="button"
              className={`h-9 flex-1 rounded-md text-sm font-medium transition-[background-color,color] duration-150 ${
                language === "en" ? "bg-elevated text-ink" : "text-muted hover:text-ink"
              }`}
              onClick={() => setLanguage("en")}
              aria-pressed={language === "en"}
            >
              EN · {ui.english}
            </button>
          </div>

          <label className="mb-1.5 block text-sm font-medium text-ink" htmlFor="gate-name">
            {ui.gateName}
          </label>
          <Input
            id="gate-name"
            autoComplete="name"
            autoFocus
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={ui.gateNamePlaceholder}
            maxLength={40}
          />

          <div className="mt-5">
            <div className="mb-1.5 flex items-center justify-between gap-3">
              <label className="text-sm font-medium text-ink" htmlFor="gate-captcha">
                {ui.gateCaptcha}
              </label>
              <button
                type="button"
                onClick={refreshCaptcha}
                className="inline-flex size-9 items-center justify-center rounded-md text-muted hover:bg-elevated hover:text-ink focus-visible:ring-2 focus-visible:ring-ring/70"
                aria-label={ui.gateCaptchaRefresh}
              >
                <RefreshCw className="size-4" />
              </button>
            </div>
            <div className="captcha-box mb-3 flex h-14 items-center justify-center gap-1 rounded-lg" aria-hidden="true">
              {challenge.split("").map((ch, i) => (
                <span key={`${ch}-${i}`} className="captcha-ch font-mono text-xl tracking-widest text-ink">
                  {ch}
                </span>
              ))}
            </div>
            <Input
              id="gate-captcha"
              autoComplete="off"
              spellCheck={false}
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder="—————"
              maxLength={8}
              aria-describedby="captcha-hint"
              className="font-mono tracking-[0.3em]"
            />
            <p id="captcha-hint" className="mt-2 text-xs text-subtle">
              {ui.gateCaptchaHint}
            </p>
          </div>

          {error ? (
            <p className="mt-4 text-sm text-danger" role="alert">
              {error}
            </p>
          ) : null}

          <Button type="submit" className="mt-6 w-full">
            {ui.gateSubmit}
          </Button>
        </form>
      </div>
    </main>
  );
}
