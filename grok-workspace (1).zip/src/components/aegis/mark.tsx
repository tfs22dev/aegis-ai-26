import { cn } from "@/lib/utils";

export function AegisMark({ className, title = "AEGIS" }: { className?: string; title?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("text-ink", className)}
      aria-hidden={title ? undefined : true}
      role="img"
    >
      {title ? <title>{title}</title> : null}
      <path
        d="M16 3.5 26 8v9.2c0 5.4-4.1 9.6-10 11.3C10.1 26.8 6 22.6 6 17.2V8L16 3.5Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinejoin="round"
      />
      <path
        d="M16 9.2v10.4M12.4 16.2h7.2"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
    </svg>
  );
}
