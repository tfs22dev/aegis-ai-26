import type { ReactNode } from "react";

function safeUrl(href: string): string | null {
  try {
    const url = new URL(href, "https://aegis.local");
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    return url.href;
  } catch {
    return null;
  }
}

function inline(text: string, keyPrefix: string): ReactNode[] {
  const nodes: ReactNode[] = [];
  const re = /(`[^`]+`)|(\*\*[^*]+\*\*)|(\*[^*]+\*)|(\[[^\]]+\]\([^)]+\))/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let i = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) {
      nodes.push(<span key={`${keyPrefix}-t${i}`}>{text.slice(last, m.index)}</span>);
      i += 1;
    }
    const token = m[0];
    if (token.startsWith("`")) {
      nodes.push(
        <code key={`${keyPrefix}-c${i}`} className="md-code">
          {token.slice(1, -1)}
        </code>,
      );
    } else if (token.startsWith("**")) {
      nodes.push(
        <strong key={`${keyPrefix}-b${i}`} className="font-medium">
          {token.slice(2, -2)}
        </strong>,
      );
    } else if (token.startsWith("*")) {
      nodes.push(
        <em key={`${keyPrefix}-i${i}`} className="italic">
          {token.slice(1, -1)}
        </em>,
      );
    } else {
      const lm = /^\[([^\]]+)\]\(([^)]+)\)$/.exec(token);
      const href = lm ? safeUrl(lm[2]) : null;
      if (lm && href) {
        nodes.push(
          <a
            key={`${keyPrefix}-a${i}`}
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            className="md-link"
          >
            {lm[1]}
          </a>,
        );
      } else {
        nodes.push(<span key={`${keyPrefix}-f${i}`}>{token}</span>);
      }
    }
    i += 1;
    last = m.index + token.length;
  }
  if (last < text.length) nodes.push(<span key={`${keyPrefix}-end`}>{text.slice(last)}</span>);
  return nodes;
}

function isTableSep(line: string): boolean {
  return /^\s*\|?[\s:|-]+\|[\s:|-]+/.test(line);
}

function isTableRow(line: string): boolean {
  return line.includes("|") && line.split("|").length > 2;
}

function parseTable(lines: string[], start: number): { node: ReactNode; next: number } | null {
  const header = lines[start];
  const sep = lines[start + 1];
  if (!header || !sep || !isTableSep(sep) || !isTableRow(header)) return null;
  const split = (line: string) =>
    line
      .trim()
      .replace(/^\|/, "")
      .replace(/\|$/, "")
      .split("|")
      .map((c) => c.trim());
  const heads = split(header);
  const rows: string[][] = [];
  let i = start + 2;
  while (i < lines.length && isTableRow(lines[i])) {
    rows.push(split(lines[i]));
    i += 1;
  }
  return {
    next: i,
    node: (
      <div key={`tbl-${start}`} className="md-table-wrap">
        <table className="md-table">
          <thead>
            <tr>
              {heads.map((h, idx) => (
                <th key={idx}>{inline(h, `th-${start}-${idx}`)}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, r) => (
              <tr key={r}>
                {heads.map((_, c) => (
                  <td key={c}>{inline(row[c] ?? "", `td-${start}-${r}-${c}`)}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    ),
  };
}

export function Markdown({ text }: { text: string }) {
  const blocks: ReactNode[] = [];
  const parts = text.split(/```/);
  let key = 0;
  for (let p = 0; p < parts.length; p += 1) {
    const chunk = parts[p];
    if (p % 2 === 1) {
      const nl = chunk.indexOf("\n");
      const code = nl === -1 ? chunk : chunk.slice(nl + 1);
      blocks.push(
        <pre key={`code-${key}`} className="md-pre">
          <code>{code.replace(/\n$/, "")}</code>
        </pre>,
      );
      key += 1;
      continue;
    }
    const lines = chunk.split("\n");
    let i = 0;
    let para: string[] = [];
    const flushPara = () => {
      if (!para.length) return;
      const body = para.join("\n").trim();
      para = [];
      if (!body) return;
      blocks.push(
        <p key={`p-${key}`} className="md-p">
          {inline(body, `p${key}`)}
        </p>,
      );
      key += 1;
    };
    while (i < lines.length) {
      const line = lines[i];
      const heading = /^(#{1,3})\s+(.+)$/.exec(line);
      if (heading) {
        flushPara();
        const level = heading[1].length;
        const Tag = (level === 1 ? "h1" : level === 2 ? "h2" : "h3") as "h1" | "h2" | "h3";
        blocks.push(
          <Tag key={`h-${key}`} className={`md-h md-h${level}`}>
            {inline(heading[2], `h${key}`)}
          </Tag>,
        );
        key += 1;
        i += 1;
        continue;
      }
      if (/^\s*>\s?/.test(line)) {
        flushPara();
        const quote: string[] = [];
        while (i < lines.length && /^\s*>\s?/.test(lines[i])) {
          quote.push(lines[i].replace(/^\s*>\s?/, ""));
          i += 1;
        }
        blocks.push(
          <blockquote key={`q-${key}`} className="md-quote">
            {inline(quote.join(" "), `q${key}`)}
          </blockquote>,
        );
        key += 1;
        continue;
      }
      if (/^\s*[-*]\s+/.test(line)) {
        flushPara();
        const items: string[] = [];
        while (i < lines.length && /^\s*[-*]\s+/.test(lines[i])) {
          items.push(lines[i].replace(/^\s*[-*]\s+/, ""));
          i += 1;
        }
        blocks.push(
          <ul key={`ul-${key}`} className="md-ul">
            {items.map((item, idx) => (
              <li key={idx}>{inline(item, `uli${key}-${idx}`)}</li>
            ))}
          </ul>,
        );
        key += 1;
        continue;
      }
      if (/^\s*\d+\.\s+/.test(line)) {
        flushPara();
        const items: string[] = [];
        while (i < lines.length && /^\s*\d+\.\s+/.test(lines[i])) {
          items.push(lines[i].replace(/^\s*\d+\.\s+/, ""));
          i += 1;
        }
        blocks.push(
          <ol key={`ol-${key}`} className="md-ol">
            {items.map((item, idx) => (
              <li key={idx}>{inline(item, `oli${key}-${idx}`)}</li>
            ))}
          </ol>,
        );
        key += 1;
        continue;
      }
      const table = parseTable(lines, i);
      if (table) {
        flushPara();
        blocks.push(table.node);
        i = table.next;
        key += 1;
        continue;
      }
      if (line.trim() === "") {
        flushPara();
        i += 1;
        continue;
      }
      para.push(line);
      i += 1;
    }
    flushPara();
  }
  return <div className="md-root">{blocks}</div>;
}

export function plainTextFromMarkdown(text: string): string {
  return text
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/[#>*`_[\]]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
