export async function fetchJson<T>(
  url: string,
  timeoutMs = 8000,
  init?: RequestInit,
): Promise<{ ok: true; data: T } | { ok: false; kind: "network" | "http" | "timeout" | "parse" }> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      ...init,
      signal: ctrl.signal,
      headers: { Accept: "application/json", ...(init?.headers ?? {}) },
    });
    if (!res.ok) return { ok: false, kind: "http" };
    try {
      const data = (await res.json()) as T;
      return { ok: true, data };
    } catch {
      return { ok: false, kind: "parse" };
    }
  } catch (err) {
    const name = err instanceof Error ? err.name : "";
    if (name === "AbortError") return { ok: false, kind: "timeout" };
    return { ok: false, kind: "network" };
  } finally {
    clearTimeout(timer);
  }
}

export function isOnline(): boolean {
  if (typeof navigator === "undefined") return true;
  return navigator.onLine;
}
