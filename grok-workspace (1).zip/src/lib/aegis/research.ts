import type { Language, RelatedImage, Source } from "./types";
import { fetchJson } from "./net";

interface WikiSearch {
  query?: { search?: { title: string; snippet?: string }[] };
}

interface WikiExtracts {
  query?: {
    pages?: Record<
      string,
      { title?: string; extract?: string; fullurl?: string; missing?: boolean }
    >;
  };
}

interface CommonsQuery {
  query?: {
    pages?: Record<
      string,
      {
        title?: string;
        imageinfo?: {
          url?: string;
          thumburl?: string;
          mime?: string;
          descriptionurl?: string;
        }[];
      }
    >;
  };
}

interface DdgResponse {
  AbstractText?: string;
  AbstractURL?: string;
  Heading?: string;
  Answer?: string;
  AnswerType?: string;
  Definition?: string;
  RelatedTopics?: { Text?: string; FirstURL?: string }[];
}

function wikiHost(language: Language): string {
  return language === "pt" ? "pt.wikipedia.org" : "en.wikipedia.org";
}

export async function searchWikipedia(
  query: string,
  language: Language,
): Promise<{ text: string; sources: Source[] } | null> {
  const host = wikiHost(language);
  const searchUrl =
    `https://${host}/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}` +
    `&srlimit=3&format=json&origin=*&utf8=1`;
  const search = await fetchJson<WikiSearch>(searchUrl, 8000);
  const hits = search.ok ? (search.data.query?.search ?? []) : [];
  let titles = hits.map((h) => h.title).filter(Boolean);
  if (!titles.length && language === "pt") {
    const en = await searchWikipedia(query, "en");
    return en;
  }
  if (!titles.length) return null;
  const titlesParam = titles.slice(0, 2).join("|");
  const extractUrl =
    `https://${host}/w/api.php?action=query&prop=extracts|info&exintro=1&explaintext=1` +
    `&inprop=url&redirects=1&format=json&origin=*&titles=${encodeURIComponent(titlesParam)}`;
  const extracts = await fetchJson<WikiExtracts>(extractUrl, 8000);
  if (!extracts.ok) return null;
  const pages = Object.values(extracts.data.query?.pages ?? {});
  const usable = pages.filter((p) => p.extract && !p.missing);
  if (!usable.length) return null;
  const sources: Source[] = usable
    .filter((p) => p.fullurl && p.title)
    .map((p) => ({ title: p.title as string, url: p.fullurl as string }));
  const text = usable
    .map((p) => `### ${p.title}\n\n${(p.extract ?? "").trim()}`)
    .join("\n\n");
  return { text, sources };
}

export async function searchImages(query: string): Promise<RelatedImage[]> {
  const url =
    `https://commons.wikimedia.org/w/api.php?action=query&generator=search` +
    `&gsrsearch=${encodeURIComponent(query)}&gsrnamespace=6&gsrlimit=6` +
    `&prop=imageinfo&iiprop=url|mime|size&iiurlwidth=640&format=json&origin=*`;
  const result = await fetchJson<CommonsQuery>(url, 8000);
  if (!result.ok) return [];
  const pages = Object.values(result.data.query?.pages ?? {});
  const images: RelatedImage[] = [];
  for (const page of pages) {
    const info = page.imageinfo?.[0];
    if (!info?.url || !info.mime?.startsWith("image/")) continue;
    if (info.mime.includes("svg")) continue;
    images.push({
      url: info.url,
      thumb: info.thumburl || info.url,
      title: (page.title ?? "").replace(/^File:/, ""),
      pageUrl: info.descriptionurl || info.url,
    });
  }
  return images.slice(0, 6);
}

export function formatDdg(data: DdgResponse): { text: string; sources: Source[] } | null {
  const sources: Source[] = [];
  const chunks: string[] = [];
  if (data.Heading) chunks.push(`### ${data.Heading}`);
  if (data.AbstractText) chunks.push(data.AbstractText);
  if (data.Answer) chunks.push(data.Answer);
  if (data.Definition) chunks.push(data.Definition);
  if (data.AbstractURL) {
    sources.push({
      title: data.Heading || data.AbstractURL,
      url: data.AbstractURL,
    });
  }
  if (!chunks.length && data.RelatedTopics?.length) {
    const top = data.RelatedTopics.filter((t) => t.Text).slice(0, 4);
    if (top.length) {
      chunks.push(top.map((t) => `- ${t.Text}`).join("\n"));
      for (const t of top) {
        if (t.FirstURL && t.Text) sources.push({ title: t.Text.slice(0, 80), url: t.FirstURL });
      }
    }
  }
  if (!chunks.length) return null;
  return { text: chunks.join("\n\n"), sources };
}

export function extractImageQuery(raw: string): string {
  const stripped = raw
    .replace(
      /^(mostra(?:-me)?(?:\s+(?:uma\s+)?imagens?)?|show\s+me(?:\s+an?)?(?:\s+images?)?|imagens?\s+(?:de|da|do)|image(?:s)?\s+of|picture(?:s)?\s+of|fotos?\s+(?:de|da|do))\s+/i,
      "",
    )
    .trim();
  return stripped || raw.trim();
}

export function isImageQuery(raw: string): boolean {
  return /(mostra(?:-me)?(?:\s+(?:uma\s+)?imagens?)?|show me (an? )?(image|picture)|imagens?\s+(de|da|do)|fotos?\s+(de|da|do)|picture of|images? of)/i.test(
    raw,
  );
}

export function isTimeQuery(raw: string): boolean {
  return /(que horas|what time|data de hoje|what(?:'s| is)( the)? date|dia de hoje|hora actual|hora atual|que dia é)/i.test(
    raw,
  );
}
