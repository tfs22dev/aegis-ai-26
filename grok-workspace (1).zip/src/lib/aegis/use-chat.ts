import { toast } from "sonner";
import { uid } from "@/lib/utils";
import { processQuery } from "./engine";
import { t } from "./i18n";
import { currentConversation, useAegisStore } from "./store";
import type { Attachment, ChatMessage } from "./types";
import { LIMITS } from "./types";
import { speak, stopSpeaking } from "./voice";

export function useChat() {
  const language = useAegisStore((s) => s.language);
  const memory = useAegisStore((s) => s.memory);
  const isProcessing = useAegisStore((s) => s.isProcessing);
  const voiceEnabled = useAegisStore((s) => s.voiceEnabled);
  const autoSpeak = useAegisStore((s) => s.autoSpeak);

  async function run(
    text: string,
    attachments?: Attachment[],
    options?: { history?: ChatMessage[]; skipUser?: boolean },
  ) {
    const store = useAegisStore.getState();
    const ui = t(store.language);
    const trimmed = text.trim();
    const skipUser = options?.skipUser ?? false;
    if (store.isProcessing) return;
    if (!trimmed && !attachments?.length) {
      toast.error(ui.errorEmpty);
      return;
    }
    if (trimmed.length > LIMITS.message) {
      toast.error(ui.errorTooLong);
      return;
    }

    if (!skipUser) {
      store.appendMessage({
        id: uid("m"),
        role: "user",
        content: trimmed || (store.language === "pt" ? "(imagem anexada)" : "(attached image)"),
        createdAt: Date.now(),
        attachments,
      });
      store.rememberTopic(trimmed);
    }
    store.setProcessing(true);
    stopSpeaking();

    const conv = currentConversation(useAegisStore.getState());
    const history = options?.history ?? conv?.messages ?? [];

    try {
      const result = await processQuery({
        text: trimmed,
        language: store.language,
        memory: store.memory,
        history,
      });
      store.appendMessage({
        id: uid("m"),
        role: "assistant",
        content: result.text,
        createdAt: Date.now(),
        tool: result.tool,
        sources: result.sources,
        images: result.images,
        error: result.error,
      });
      if (store.voiceEnabled && store.autoSpeak && !result.error) {
        speak(result.text, store.language);
      }
    } catch (err) {
      console.error("processQuery", err);
      store.appendMessage({
        id: uid("m"),
        role: "assistant",
        content: ui.errorGeneric,
        createdAt: Date.now(),
        tool: "local",
        error: true,
      });
    } finally {
      store.setProcessing(false);
    }
  }

  async function regenerate() {
    const store = useAegisStore.getState();
    const conv = currentConversation(store);
    if (!conv || store.isProcessing) return;
    const lastUser = [...conv.messages].reverse().find((m) => m.role === "user");
    if (!lastUser) return;
    store.removeLastAssistant();
    const history = currentConversation(useAegisStore.getState())?.messages ?? [];
    await run(lastUser.content, lastUser.attachments, { history, skipUser: true });
  }

  return { send: run, regenerate, isProcessing, language, memory, voiceEnabled, autoSpeak };
}
