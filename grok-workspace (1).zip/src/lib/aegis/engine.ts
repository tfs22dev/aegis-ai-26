import { calculate, formatNumber, looksLikeMath } from "./calculator";
import { t } from "./i18n";
import { isOnline } from "./net";
import { extractImageQuery, isImageQuery, isTimeQuery, searchImages, searchWikipedia } from "./research";
import { completeChat, instantAnswer } from "./server";
import type { ChatMessage, Language, LongTermMemory, QueryResult, Source } from "./types";
import { LIMITS } from "./types";

function memoryBlock(memory: LongTermMemory, language: Language): string {
  const lines: string[] = [];
  if (memory.userName) lines.push(`${language === "pt" ? "Nome" : "Name"}: ${memory.userName}`);
  if (memory.notes.length) lines.push(memory.notes.map((n) => `- ${n}`).join("\n"));
  if (memory.recentTopics.length) {
    lines.push(
      (language === "pt" ? "Tópicos recentes: " : "Recent topics: ") + memory.recentTopics.join("; "),
    );
  }
  return lines.join("\n").slice(0, 1800);
}

function mergeSources(...lists: (Source[] | undefined)[]): Source[] {
  const seen = new Set<string>();
  const out: Source[] = [];
  for (const list of lists) {
    if (!list) continue;
    for (const s of list) {
      if (seen.has(s.url)) continue;
      seen.add(s.url);
      out.push(s);
    }
  }
  return out.slice(0, 6);
}

async function tryModel(
  query: string,
  language: Language,
  memory: LongTermMemory,
  history: ChatMessage[],
  research?: string,
): Promise<string | null> {
  const messages = history
    .filter((m) => m.role === "user" || m.role === "assistant")
    .slice(-LIMITS.contextMessages)
    .map((m) => ({ role: m.role as "user" | "assistant", content: m.content.slice(0, 4000) }));
  if (!messages.length || messages[messages.length - 1]?.content !== query) {
    messages.push({ role: "user", content: query.slice(0, LIMITS.message) });
  }
  try {
    const result = await completeChat({
      data: {
        language,
        memory: memoryBlock(memory, language),
        research,
        messages,
      },
    });
    if (result.ok) return result.text;
    return null;
  } catch (err) {
    console.error("completeChat", err);
    return null;
  }
}

async function tryInstant(query: string): Promise<{ text: string; sources: Source[] } | null> {
  try {
    const result = await instantAnswer({ data: { query: query.slice(0, 200) } });
    if (result.ok) return { text: result.text, sources: result.sources };
    return null;
  } catch (err) {
    console.error("instantAnswer", err);
    return null;
  }
}

export async function processQuery(input: {
  text: string;
  language: Language;
  memory: LongTermMemory;
  history: ChatMessage[];
}): Promise<QueryResult> {
  const { language, memory, history } = input;
  const text = input.text.trim().slice(0, LIMITS.message);
  const ui = t(language);

  if (!text) {
    return { text: ui.errorEmpty, tool: "local", error: true };
  }

  if (looksLikeMath(text)) {
    const result = calculate(text);
    if (!result.ok) {
      return { text: ui.errorCalc, tool: "calculator", error: true };
    }
    return {
      tool: "calculator",
      text: `**${ui.calcResult}**\n\n\`${result.expression} = ${formatNumber(result.value, language)}\``,
    };
  }

  if (isTimeQuery(text)) {
    const when = new Date().toLocaleString(language === "pt" ? "pt-PT" : "en-US", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
    return { tool: "time", text: ui.timeAnswer(when) };
  }

  if (isImageQuery(text)) {
    if (!isOnline()) return { text: ui.errorNetwork, tool: "images", error: true };
    const q = extractImageQuery(text);
    const images = await searchImages(q);
    if (!images.length) {
      return { text: ui.noImages, tool: "images", error: true };
    }
    const list = images
      .map((img) => `- [${img.title}](${img.pageUrl})`)
      .join("\n");
    return {
      tool: "images",
      text: `**${ui.imagesLabel}** — ${q}\n\n${list}`,
      images,
      sources: images.map((img) => ({ title: img.title, url: img.pageUrl })),
    };
  }

  if (!isOnline()) {
    return { text: ui.errorNetwork, tool: "local", error: true };
  }

  const [wiki, ddg] = await Promise.all([
    searchWikipedia(text, language).catch((err) => {
      console.error("wikipedia", err);
      return null;
    }),
    tryInstant(text),
  ]);

  const researchParts = [wiki?.text, ddg?.text].filter(Boolean).join("\n\n").slice(0, 3800);
  const sources = mergeSources(wiki?.sources, ddg?.sources);

  const modeled = await tryModel(text, language, memory, history, researchParts || undefined);
  if (modeled) {
    return {
      tool: researchParts ? "hybrid" : "model",
      text: modeled,
      sources,
    };
  }

  if (wiki) {
    return {
      tool: "wikipedia",
      text: `${wiki.text}\n\n_${ui.wikiFallback}_`,
      sources,
    };
  }

  if (ddg) {
    return {
      tool: "search",
      text: ddg.text,
      sources,
    };
  }

  return {
    tool: "local",
    text: ui.noWiki,
    error: true,
  };
}
