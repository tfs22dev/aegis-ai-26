/**
 * Interface-layer CAPTCHA. Not cryptographic authentication.
 * Generates a short code the user must type to proceed.
 */

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export function randomCaptcha(length = 5): string {
  const bytes = new Uint8Array(length);
  if (typeof crypto !== "undefined" && crypto.getRandomValues) {
    crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < length; i += 1) bytes[i] = Math.floor(Math.random() * 256);
  }
  let out = "";
  for (let i = 0; i < length; i += 1) {
    out += ALPHABET[bytes[i] % ALPHABET.length];
  }
  return out;
}

export function captchaMatches(expected: string, given: string): boolean {
  return expected.trim().toUpperCase() === given.trim().toUpperCase();
}
