export type Language = "pt" | "en";
export type Theme = "dark" | "light";
export type PanelId = "history" | "memory" | "tools" | "settings" | "help";
export type ToolName =
  | "calculator"
  | "wikipedia"
  | "search"
  | "images"
  | "time"
  | "model"
  | "hybrid"
  | "local";
export type MessageRole = "user" | "assistant" | "system";
export type Feedback = "up" | "down";

export interface Source {
  title: string;
  url: string;
}

export interface RelatedImage {
  url: string;
  thumb: string;
  title: string;
  pageUrl: string;
}

export interface Attachment {
  id: string;
  name: string;
  mime: string;
  dataUrl: string;
}

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  createdAt: number;
  tool?: ToolName;
  sources?: Source[];
  images?: RelatedImage[];
  attachments?: Attachment[];
  error?: boolean;
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
}

export interface LongTermMemory {
  userName: string;
  notes: string[];
  recentTopics: string[];
}

export interface QueryResult {
  text: string;
  tool: ToolName;
  sources?: Source[];
  images?: RelatedImage[];
  error?: boolean;
}

export const LIMITS = {
  message: 4000,
  conversations: 50,
  messagesPerConversation: 120,
  memoryNotes: 32,
  memoryNoteLength: 240,
  attachmentBytes: 1_500_000,
  contextMessages: 10,
} as const;

export const STORAGE_KEYS = {
  state: "aegis.ultra.v3.state",
  session: "aegis.ultra.v3.session",
} as const;
