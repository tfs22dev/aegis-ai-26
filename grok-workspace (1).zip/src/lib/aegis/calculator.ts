/**
 * Safe arithmetic parser. Does not use eval() or Function().
 * Supports + - * / % ^, parentheses, unary minus, and decimals.
 */

export type CalcOk = { ok: true; value: number; expression: string };
export type CalcErr = { ok: false; error: "empty" | "syntax" | "overflow" | "divzero" };
export type CalcResult = CalcOk | CalcErr;

const MAX_LEN = 200;
const MAX_ABS = 1e15;

type Tok =
  | { kind: "num"; value: number }
  | { kind: "op"; value: "+" | "-" | "*" | "/" | "%" | "^" }
  | { kind: "lp" }
  | { kind: "rp" };

function tokenize(input: string): Tok[] | null {
  const src = input.replace(/×/g, "*").replace(/÷/g, "/").replace(/,/g, ".").replace(/\s+/g, "");
  if (!src || src.length > MAX_LEN) return null;
  const tokens: Tok[] = [];
  let i = 0;
  while (i < src.length) {
    const ch = src[i];
    if (ch >= "0" && ch <= "9") {
      let j = i;
      while (j < src.length && ((src[j] >= "0" && src[j] <= "9") || src[j] === ".")) j += 1;
      const raw = src.slice(i, j);
      if (!/^\d+(\.\d+)?$/.test(raw)) return null;
      const value = Number(raw);
      if (!Number.isFinite(value)) return null;
      tokens.push({ kind: "num", value });
      i = j;
      continue;
    }
    if (ch === "+" || ch === "-" || ch === "*" || ch === "/" || ch === "%" || ch === "^") {
      tokens.push({ kind: "op", value: ch });
      i += 1;
      continue;
    }
    if (ch === "(") {
      tokens.push({ kind: "lp" });
      i += 1;
      continue;
    }
    if (ch === ")") {
      tokens.push({ kind: "rp" });
      i += 1;
      continue;
    }
    return null;
  }
  return tokens;
}

class Parser {
  i = 0;
  divZero = false;
  overflow = false;
  constructor(private tokens: Tok[]) {}

  peek(): Tok | undefined {
    return this.tokens[this.i];
  }

  eat(): Tok | undefined {
    const t = this.tokens[this.i];
    this.i += 1;
    return t;
  }

  finish(n: number): number {
    if (!Number.isFinite(n) || Math.abs(n) > MAX_ABS) {
      this.overflow = true;
      return NaN;
    }
    return n;
  }

  parse(): number {
    const v = this.expr();
    if (this.i !== this.tokens.length) return NaN;
    return v;
  }

  expr(): number {
    let v = this.term();
    while (true) {
      const tok = this.peek();
      if (tok?.kind !== "op" || (tok.value !== "+" && tok.value !== "-")) break;
      this.eat();
      const r = this.term();
      v = this.finish(tok.value === "+" ? v + r : v - r);
    }
    return v;
  }

  term(): number {
    let v = this.power();
    while (this.peek()?.kind === "op") {
      const op = (this.peek() as Extract<Tok, { kind: "op" }>).value;
      if (op !== "*" && op !== "/" && op !== "%") break;
      this.eat();
      const r = this.power();
      if ((op === "/" || op === "%") && r === 0) {
        this.divZero = true;
        return NaN;
      }
      v = this.finish(op === "*" ? v * r : op === "/" ? v / r : v % r);
    }
    return v;
  }

  power(): number {
    const v = this.unary();
    if (this.peek()?.kind === "op" && (this.peek() as Extract<Tok, { kind: "op" }>).value === "^") {
      this.eat();
      const exp = this.power();
      return this.finish(v ** exp);
    }
    return v;
  }

  unary(): number {
    if (this.peek()?.kind === "op" && (this.peek() as Extract<Tok, { kind: "op" }>).value === "-") {
      this.eat();
      return this.finish(-this.unary());
    }
    if (this.peek()?.kind === "op" && (this.peek() as Extract<Tok, { kind: "op" }>).value === "+") {
      this.eat();
      return this.unary();
    }
    return this.primary();
  }

  primary(): number {
    const t = this.peek();
    if (t?.kind === "num") {
      this.eat();
      return t.value;
    }
    if (t?.kind === "lp") {
      this.eat();
      const v = this.expr();
      if (this.peek()?.kind !== "rp") return NaN;
      this.eat();
      return v;
    }
    return NaN;
  }
}

export function extractMath(raw: string): string {
  return raw
    .replace(/^(calcula(?:r|e)?|compute|calculate|quanto é|what(?:'s| is))\s*/i, "")
    .replace(/[?=]/g, "")
    .trim();
}

export function looksLikeMath(raw: string): boolean {
  const expr = extractMath(raw);
  if (!expr || expr.length > MAX_LEN) return false;
  if (!/\d/.test(expr)) return false;
  return /^[\d\s+\-*/().,^%x×÷]+$/i.test(expr);
}

export function calculate(raw: string): CalcResult {
  const expression = extractMath(raw);
  if (!expression) return { ok: false, error: "empty" };
  const tokens = tokenize(expression);
  if (!tokens || tokens.length === 0) return { ok: false, error: "syntax" };
  const parser = new Parser(tokens);
  const value = parser.parse();
  if (parser.divZero) return { ok: false, error: "divzero" };
  if (parser.overflow) return { ok: false, error: "overflow" };
  if (!Number.isFinite(value)) return { ok: false, error: "syntax" };
  const rounded = Math.round(value * 1e12) / 1e12;
  return { ok: true, value: rounded, expression };
}

export function formatNumber(n: number, language: "pt" | "en"): string {
  try {
    return n.toLocaleString(language === "pt" ? "pt-PT" : "en-US", {
      maximumFractionDigits: 10,
    });
  } catch {
    return String(n);
  }
}
