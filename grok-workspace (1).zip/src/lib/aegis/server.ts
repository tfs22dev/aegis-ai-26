import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { formatDdg } from "./research";

const chatInput = z.object({
  language: z.enum(["pt", "en"]),
  memory: z.string().max(2000).optional(),
  research: z.string().max(4000).optional(),
  messages: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string().max(8000),
      }),
    )
    .max(12),
});

export const getAiStatus = createServerFn({ method: "GET" }).handler(async () => {
  return { available: Boolean(process.env.XAI_API_KEY) };
});

export const completeChat = createServerFn({ method: "POST" })
  .validator((input: unknown) => chatInput.parse(input))
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, reason: "unavailable" as const };

    const lang = data.language === "pt" ? "português europeu" : "English";
    const system = [
      "You are AEGIS ULTRA AI, version 3.0, a calm professional assistant.",
      `Reply in ${lang}. Use Markdown (headings, lists, tables when useful).`,
      "Be precise. Do not invent sources. If research notes are provided, use them and cite.",
      "Do not claim to have private live browsing beyond those notes.",
      data.memory ? `Long-term memory about the user:\n${data.memory}` : "",
      data.research ? `Public research notes:\n${data.research}` : "",
    ]
      .filter(Boolean)
      .join("\n\n");

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 25000);
    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        signal: controller.signal,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.5,
          max_tokens: 1200,
          messages: [{ role: "system", content: system }, ...data.messages],
        }),
      });
      if (!res.ok) {
        console.error("xAI chat error", res.status);
        return { ok: false as const, reason: "upstream" as const };
      }
      const body = (await res.json()) as {
        choices?: { message?: { content?: string } }[];
      };
      const text = body.choices?.[0]?.message?.content?.trim() ?? "";
      if (!text) return { ok: false as const, reason: "empty" as const };
      return { ok: true as const, text };
    } catch (err) {
      console.error("xAI chat failed", err);
      return { ok: false as const, reason: "network" as const };
    } finally {
      clearTimeout(timer);
    }
  });

const searchInput = z.object({
  query: z.string().min(1).max(200),
});

export const instantAnswer = createServerFn({ method: "POST" })
  .validator((input: unknown) => searchInput.parse(input))
  .handler(async ({ data }) => {
    const url =
      `https://api.duckduckgo.com/?q=${encodeURIComponent(data.query)}` +
      `&format=json&no_html=1&skip_disambig=1`;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 7000);
    try {
      const res = await fetch(url, {
        signal: controller.signal,
        headers: { Accept: "application/json" },
      });
      if (!res.ok) return { ok: false as const };
      const json = (await res.json()) as Parameters<typeof formatDdg>[0];
      const formatted = formatDdg(json);
      if (!formatted) return { ok: false as const };
      return { ok: true as const, text: formatted.text, sources: formatted.sources };
    } catch (err) {
      console.error("instant answer failed", err);
      return { ok: false as const };
    } finally {
      clearTimeout(timer);
    }
  });
